


<html>
<head>

<title>NCKU 7391</title>
<style>
body{background-color: #bec8de; }
a:link {color:#DC0300;}       
a:visited {color:#8a438d;}   
a:hover {color:#FF00FF;}
a:active {color:#0000FF;} 
p{color:#6918aa;}
</style>
</head>
<body background="bg.jpg"><div style='text-align:center'>
<?php

echo "</br></br></br>
<a href=\"index.php\" target=\"main\">HomePage</a></br></br>";


echo 
	"<a href=\"reg.php\" target=\"main\">register</a></br></br>
	<a href=\"login.php\" target=\"main\">login</a></br></br>";


echo "<a href=\"info.php\" target=\"main\">My info</a></br></br>


<a href=\"search.htm\" target=\"main\">search</a></br></br>
<a href=\"map.php\" target=\"main\">map</a></br></br>";
echo "<a href=\"logout.php\" target=\"main\">logout</a></br></br>";
echo "<a href=\"http://www.facebook.com/sharer/sharer.php?u=http://140.116.245.221/f74011069/project/index.htm\" target=blink>share on FB</a></br></br>
";


?>
</div>
</body>
</html>